package com.example.bookapi;

import java.util.List;
import java.util.Optional;

import jakarta.validation.Valid;

public class CustomerService {

	public Customer saveCustomer(@Valid Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	public Optional<Customer> getCustomerById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteCustomer(Long id) {
		// TODO Auto-generated method stub
		
	}

}
